import React from "react";
import GameBoard from "./components/Game";
import "./App.css";

function App() {
  return (
    <div className="App">
      <GameBoard />
    </div>
  );
}

export default App;
